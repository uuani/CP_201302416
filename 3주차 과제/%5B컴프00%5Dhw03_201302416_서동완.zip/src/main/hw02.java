package main;

import java.util.*;

public class hw02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.print("문자를 입력하세요. : ");
		String input = sc.nextLine();

		switch (input) {
		case "a":
		case "e":
		case "i":
		case "o":
		case "u":
			System.out.println("모음입니다.");
			break;

		default:
			System.out.println("자음입니다.");
		}

	}

}
