package main;

public class hw01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int pre_pre = 1;
		int pre = 0;
		int result = 0;

		for (int i = 0; i < 10; i++) {
			result = pre + pre_pre;
			pre = pre_pre;
			pre_pre = result;
			System.out.println(result);
		}

	}

}
