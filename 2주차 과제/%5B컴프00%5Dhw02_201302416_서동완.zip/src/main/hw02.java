package main;

import java.util.*;

public class hw02 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 입력 받은 날짜까지 총 몇일이 지났는지 알아낸다음,
		// 그 날짜를 7로 나눈 나머지에 따라
		// 일/월/화/수/목/금/토 요일을 계산

		Scanner sc = new Scanner(System.in);
		boolean isleapYear = false;
		int totaldays = 0;
		int year = 0;
		int month = 0;
		int day = 0;

		System.out.println("년도를 입력하세요. 1900년도 이후 날짜로 입력하세요.");
		year = sc.nextInt();

		System.out.println("월을 입력하세요. 12월까지의 범위로 입력하세요.");
		month = sc.nextInt();

		System.out.println("일을 입력하세요. 31일까지의 범위로 입력하세요.");
		day = sc.nextInt();

		/////////////////// 입력완료//////////////////
		if (((year % 4 == 0) && (year % 100 != 0)) || year % 400 == 0)
			isleapYear = true;

		for (int i = 1900; i < year; i++) {
			if (((i % 4 == 0) && (i % 100 != 0)) || i % 400 == 0)
				totaldays = totaldays + 366;
			else
				totaldays = totaldays + 365;
		}

		// System.out.println(totaldays);
		//////////////// 연도 완료 ///////////////////////

		if (isleapYear == false) {
			for (int i = 1; i < month; i++) {
				if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12)
					totaldays = totaldays + 31;
				else if (i == 2)
					totaldays = totaldays + 28;
				else
					totaldays = totaldays + 30;
			}
		} else {
			for (int j = 1; j < month; j++) {
				if (j == 1 || j == 3 || j == 5 || j == 7 || j == 8 || j == 10 || j == 12)
					totaldays = totaldays + 31;
				else if (j == 2)
					totaldays = totaldays + 29;
				else
					totaldays = totaldays + 30;
			}

		}

		// System.out.println(totaldays);

		totaldays = totaldays + day;

		// System.out.println(totaldays);

		if ((totaldays % 7) == 0)
			System.out.println("일요일입니다.");
		else if ((totaldays % 7) == 1)
			System.out.println("월요일입니다.");
		else if ((totaldays % 7) == 2)
			System.out.println("화요일입니다.");
		else if ((totaldays % 7) == 3)
			System.out.println("수요일입니다.");
		else if ((totaldays % 7) == 4)
			System.out.println("목요입니다.");
		else if ((totaldays % 7) == 5)
			System.out.println("금요일입니다.");
		else if ((totaldays % 7) == 6)
			System.out.println("토요일입니다.");

	}

}
