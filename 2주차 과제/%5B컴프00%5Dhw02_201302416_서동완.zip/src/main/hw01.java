package main;

import java.util.*;

public class hw01 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int stageCount = 1;
		int userWin = 0;
		int comWin = 0;

		System.out.println("(가위, 바위, 보) 중에 하나를 '정확'하게 입력하세요.");
		System.out.println("그렇지 않으면 집니다.");
		while (stageCount != 8) {
			int computerNum = (int) (Math.random() * 10) + 1;
			System.out.println("stage " + stageCount + " > ");
			String input = sc.nextLine();

			switch (computerNum) {

			case 1:
			case 4:
			case 7:
				System.out.println("컴퓨터는 '가위'를 냈습니다.");
				if (input.equals("바위")) {
					System.out.println("이겼다!");
					System.out.println("user : " + ++userWin + "승 vs computer : " + comWin + "승");
					break;
				} else if (input.equals("가위")) {
					System.out.println("비겼다!");
					System.out.println("user : " + userWin + "승 vs computer : " + comWin + "승");
					break;
				} else if (input.equals("보")) {
					System.out.println("졌다!");
					System.out.println("user : " + userWin + "승 vs computer : " + ++comWin + "승");
					break;

				}
				break;

			case 2:
			case 5:
			case 8:
				System.out.println("컴퓨터는 '바위'를 냈습니다.");
				if (input.equals("바위")) {
					System.out.println("비겼다!");
					System.out.println("user : " + userWin + "승 vs computer : " + comWin + "승");
					break;
				} else if (input.equals("가위")) {
					System.out.println("졌다!");
					System.out.println("user : " + userWin + "승 vs computer : " + ++comWin + "승");
					break;
				} else if (input.equals("보")) {
					System.out.println("이겼다!");
					System.out.println("user : " + ++userWin + "승 vs computer : " + comWin + "승");
					break;
				}
				break;

			case 3:
			case 6:
			case 9:
				System.out.println("컴퓨터는 '보'를 냈습니다.");
				if (input.equals("바위")) {
					System.out.println("졌다!");
					System.out.println("user : " + userWin + "승 vs computer : " + ++comWin + "승");
					break;
				} else if (input.equals("가위")) {
					System.out.println("이겼다!");
					System.out.println("user : " + ++userWin + "승 vs computer : " + comWin + "승");
					break;
				} else if (input.equals("보")) {
					System.out.println("비겼다!");
					System.out.println("user : " + userWin + "승 vs computer : " + comWin + "승");
					break;
				}
				break;

			default:
				System.out.println("컴퓨터가 반칙했습니다.");
				// System.out.println("무효게임이므로 다시 진행하세요.");
				System.out.println("user : " + ++userWin + "승 vs computer : " + comWin + "승");
				break;
			}

			if (!input.equals("가위") && !input.equals("바위") && !input.equals("보")) {
				System.out.println("당신은 잘못된 것을 냈습니다.");
				System.out.println("정확하게 입력하십시오!");
				// System.out.println("무효게임이므로 다시 진행하세요.");
				System.out.println("user : " + userWin + "승 vs computer : " + ++comWin + "승");
			}
			stageCount++;
		}
		System.out.println("-----------------------------------------------------");
		System.out.println("결과는!");
		if (userWin > comWin)
			System.out.println("user 승 입니다!");
		else if (userWin < comWin)
			System.out.println("computer 승 입니다!");
		else
			System.out.println("비겼습니다. 게임을 다시 진행하세요!");
	}
}
