package main;

import java.util.*;

public class hw05_Date {
	int year;
	int month;
	int day;

	public void printEastern(int year, int month, int day) {
		System.out.println("동양식 날짜 표현 : " + year + "." + month + "." + day);
	}

	public void printWestern(int year, int month, int day) {
		String changed_month = null;

		switch (month) {
			case 1:  changed_month = "January";   break;
			case 2:  changed_month = "February";  break;
			case 3:  changed_month = "March";     break;
			case 4:  changed_month = "Apil";      break;
			case 5:  changed_month = "May";       break;
			case 6:  changed_month = "June";      break;
			case 7:  changed_month = "July";      break;
			case 8:  changed_month = "August";    break;
			case 9:  changed_month = "September"; break;
			case 10: changed_month = "October";   break;
			case 11: changed_month = "November";  break;
			case 12: changed_month = "December";  break;
		}
		
		System.out.println("미국식 날짜 표현 : " + changed_month + " " + day + ", " + year);
	}
}
