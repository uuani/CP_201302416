package main;

import java.util.*;

public class hw05_02 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();

		for (int i = 0; i < input.length(); i++) {

			if (input.charAt(i) >= 'A' && input.charAt(i) <= 'Z')
				System.out.print(toLower(input.charAt(i)));

			else if (input.charAt(i) >= 'a' && input.charAt(i) <= 'z')
				System.out.print(toUpper(input.charAt(i)));

			else
				System.out.print(" ");
		}
	}

	public static char toLower(char upper_c) {
		int ascii_lower = upper_c; // 아스키코드 변환 완료

		return (char) ((char) ascii_lower + 32);
	}

	public static char toUpper(char lower_c) {
		int ascii_upper = lower_c; // 아스키코드 변환 완료

		return (char) ((char) ascii_upper - 32);
	}
}
