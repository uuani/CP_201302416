package main;

import java.util.*;

public class hw05_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		int jaeum_cnt = 0;
		int moeum_cnt = 0;

		System.out.println("문자열을 입력하시오. ");
		String s = sc.nextLine();

		String newString = s.replaceAll("[0-9]", "");

		for (int i = 0; i < newString.length(); i++) {
			if (newString.charAt(i) == 'a' || newString.charAt(i) == 'e' || newString.charAt(i) == 'i'
					|| newString.charAt(i) == 'o' || newString.charAt(i) == 'u')
				moeum_cnt++;
			else
				jaeum_cnt++;
		}

		System.out.println("자음의 개수 : " + jaeum_cnt + "개");
		System.out.println("모음의 개수 : " + moeum_cnt + "개");

	}

}
