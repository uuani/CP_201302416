package main;

import java.util.*;

public class hw05_TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hw05_Date date = new hw05_Date();
		
		Scanner sc = new Scanner(System.in);

		System.out.print("연도 입력 : ");
		date.year = sc.nextInt();
		System.out.print("월 입력 : ");
		date.month = sc.nextInt();
		System.out.print("일 입력 : ");
		date.day = sc.nextInt();
		System.out.println();

		date.printEastern(date.year, date.month, date.day);
		date.printWestern(date.year, date.month, date.day);

	}
}
