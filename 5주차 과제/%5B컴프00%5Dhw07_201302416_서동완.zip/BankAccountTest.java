import java.util.*;

public class BankAccountTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);

        BankAccount bankAccount_1 = new BankAccount();
        BankAccount bankAccount_2 = new BankAccount();

        System.out.println("계좌1 정보 입력");
        System.out.print("계좌번호 : ");
        bankAccount_1.accountNumber = sc.nextLine();

        System.out.print("예금주 : ");
        bankAccount_1.owner = sc.nextLine();

        System.out.print("초기 잔액 : ");
        bankAccount_1.balance = sc.nextInt();

        System.out.println("\n계좌2 정보 입력");
        System.out.print("계좌번호 : ");
        bankAccount_2.accountNumber = sc2.nextLine();

        System.out.print("예금주 : ");
        bankAccount_2.owner = sc2.nextLine();

        System.out.print("초기 잔액 : ");
        bankAccount_2.balance = sc2.nextInt();


        System.out.println("\n계좌1에서 계좌로 송금할 금액 : ");
        int temp = sc.nextInt();
        bankAccount_1.sendAccount(temp, bankAccount_2);


        System.out.println("\n=============================");

        System.out.println("계좌1");
        System.out.print("계좌번호 : ");
        System.out.println(bankAccount_1.accountNumber);

        System.out.print("예금주 : ");
        System.out.println(bankAccount_1.owner);

        System.out.println(bankAccount_1);
        System.out.println();

        System.out.println("계좌2");
        System.out.print("계좌번호 : ");
        System.out.println(bankAccount_2.accountNumber);

        System.out.print("예금주 : ");
        System.out.println(bankAccount_2.owner);

        System.out.println(bankAccount_2);


    }
}
